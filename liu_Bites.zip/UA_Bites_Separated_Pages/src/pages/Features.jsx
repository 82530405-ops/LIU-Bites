import React from 'react';

function Features() {
  return <section><h1>Our Features</h1><div className="cards"><article><h3>📋 Menu</h3><p>Browse available food and drinks.</p></article><article><h3>🛒 Cart</h3><p>Choose your meals and see the total.</p></article><article><h3>🧾 Orders</h3><p>Place a demo order and view its details.</p></article></div></section>;
}

export default Features;
