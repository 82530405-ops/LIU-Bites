import React from 'react';

function About() {
  return <section><h1>About LIU Bites</h1><p>LIU Bites is a project for making cafeteria ordering easier fOr students at university.</p><p>Students can view meals, add items to their cart, and place a sample order online.</p></section>;
}

export default About;
