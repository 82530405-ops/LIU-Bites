import React from 'react';

function Orders({ orders }) {
  return <section><h1>My Orders</h1>{orders.length === 0 ? <p>No orders yet.</p> : orders.map(order => <article className="order" key={order.id}><h3>Order #{order.id}</h3><p>{order.items.map(item => item.name + ' x' + item.quantity).join(', ')}</p><p>Total: ${order.total.toFixed(2)}</p><p>Status: Received (demo)</p></article>)}</section>;
}

export default Orders;
