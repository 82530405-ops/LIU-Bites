import React from 'react';
import { Link } from 'react-router-dom';

function Cart({ cart, changeQuantity, placeOrder }) {
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
  return <section><h1>My Cart</h1>{cart.length === 0 ? <p>Your cart is empty. <Link to="/menu">Go to menu</Link></p> : <><div>{cart.map(item => <div className="cart-row" key={item.id}><span>{item.emoji} {item.name}</span><div><button onClick={() => changeQuantity(item.id, -1)}>-</button> {item.quantity} <button onClick={() => changeQuantity(item.id, 1)}>+</button></div><span>${(item.price * item.quantity).toFixed(2)}</span></div>)}</div><h2>Total: ${total.toFixed(2)}</h2><button onClick={placeOrder}>Place Demo Order</button><p className="note">No real payment or cafeteria order is made.</p></>}</section>;
}

export default Cart;
