import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import foods from '../data/foods';

function Menu({ addToCart }) {
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const filtered = foods.filter(food => food.name.toLowerCase().includes(search.toLowerCase()) && (category === 'All' || food.category === category));
  return <section><h1>Food Menu</h1><div className="filters"><input placeholder="Search for food..." value={search} onChange={e => setSearch(e.target.value)}/><select value={category} onChange={e => setCategory(e.target.value)}><option>All</option><option>Sandwiches</option><option>Snacks</option><option>Drinks</option></select></div><div className="cards">{filtered.map(food => <article key={food.id}><div className="food-icon">{food.emoji}</div><h3>{food.name}</h3><p>${food.price.toFixed(2)}</p><Link to={'/food/' + food.id}>Details</Link><button onClick={() => addToCart(food)}>Add to Cart</button></article>)}</div>{filtered.length === 0 && <p>No matching food found.</p>}</section>;
}

export default Menu;
