import React from 'react';
import { useParams } from 'react-router-dom';
import foods from '../data/foods';

function FoodDetails({ addToCart }) {
  const { id } = useParams();
  const food = foods.find(item => item.id === Number(id));
  if (!food) return <p>Food item not found.</p>;
  return <section><h1>{food.name}</h1><div className="big-icon">{food.emoji}</div><p>Category: {food.category}</p><p>Price: ${food.price.toFixed(2)}</p><button onClick={() => addToCart(food)}>Add to Cart</button></section>;
}

export default FoodDetails;
