import React from 'react';
import { Link } from 'react-router-dom';

function Home() {
  return <section className="hero"><h1>Welcome to LIU Bites 🍔</h1><p>Order your favorite cafeteria food without waiting in line.</p><Link className="button" to="/menu">View Menu</Link></section>;
}

export default Home;
