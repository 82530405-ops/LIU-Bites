import React, { useState } from 'react';

function Contact() {
  const [name, setName] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  function submit(e) { e.preventDefault(); setSent(true); setName(''); setMessage(''); }
  return <section><h1>Contact Us</h1><p>Have a suggestion? Send us a message.</p><form onSubmit={submit}><label>Your Name<input required value={name} onChange={e => setName(e.target.value)}/></label><label>Your Message<textarea required value={message} onChange={e => setMessage(e.target.value)}/></label><button>Send Message</button></form>{sent && <p className="success">Message submitted.</p>}</section>;
}

export default Contact;
