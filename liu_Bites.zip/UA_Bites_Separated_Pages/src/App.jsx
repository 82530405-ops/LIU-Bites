import React, { useState } from 'react';
import { Routes, Route, Link } from 'react-router-dom';
import NavBar from './components/NavBar';
import Footer from './components/Footer';
import Home from './pages/Home';
import About from './pages/About';
import Features from './pages/Features';
import Menu from './pages/Menu';
import FoodDetails from './pages/FoodDetails';
import Cart from './pages/Cart';
import Contact from './pages/Contact';
import Orders from './pages/Orders';

function App() {
  const [cart, setCart] = useState([]);
  const [orders, setOrders] = useState([]);
  const [notice, setNotice] = useState('');
  function addToCart(food) {
    setCart(current => {
      const existing = current.find(item => item.id === food.id);
      if (existing) return current.map(item => item.id === food.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...current, { ...food, quantity: 1 }];
    });
    setNotice(food.name + ' added to cart');
  }
  function changeQuantity(id, amount) {
    setCart(current => current.map(item => item.id === id ? { ...item, quantity: item.quantity + amount } : item).filter(item => item.quantity > 0));
  }
  function placeOrder() {
    if (!cart.length) return;
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);
    setOrders(current => [{ id: Date.now(), items: cart, total }, ...current]);
    setCart([]);
    setNotice('Your order was placed! Open My Orders to view it.');
  }
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  return <><NavBar count={count} /><main>{notice && <p className="notice" role="status">{notice} <button className="close" onClick={() => setNotice('')}>×</button></p>}<Routes><Route path="/" element={<Home/>}/><Route path="/about" element={<About/>}/><Route path="/features" element={<Features/>}/><Route path="/menu" element={<Menu addToCart={addToCart}/>}/><Route path="/food/:id" element={<FoodDetails addToCart={addToCart}/>}/><Route path="/cart" element={<Cart cart={cart} changeQuantity={changeQuantity} placeOrder={placeOrder}/>}/><Route path="/orders" element={<Orders orders={orders}/>}/><Route path="/contact" element={<Contact/>}/><Route path="*" element={<section><h1>Page not found</h1><Link to="/">Back Home</Link></section>}/></Routes></main><Footer /></>;
}

export default App;
