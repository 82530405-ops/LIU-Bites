import React from 'react';

function Footer() {
  return <footer>LIU Bites | CSCI426 web programming</footer>;
}

export default Footer;
