import React from 'react';
import { Link } from 'react-router-dom';

function NavBar({ count }) {
  return (<header><nav><Link className="brand" to="/">LIU Bites</Link><div className="nav-links"><Link to="/">Home</Link><Link to="/about">About</Link><Link to="/features">Features</Link><Link to="/menu">Menu</Link><Link to="/contact">Contact</Link><Link to="/orders">Orders</Link><Link to="/cart">Cart ({count})</Link></div></nav></header>);
}

export default NavBar;
