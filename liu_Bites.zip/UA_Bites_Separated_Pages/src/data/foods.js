const foods = [
  { id: 1, name: 'Chicken Sandwich', category: 'Sandwiches', price: 4.5, emoji: '🥪' },
  { id: 2, name: 'Cheese Burger', category: 'Sandwiches', price: 5, emoji: '🍔' },
  { id: 3, name: 'French Fries', category: 'Snacks', price: 2, emoji: '🍟' },
  { id: 4, name: 'Pizza Slice', category: 'Snacks', price: 3, emoji: '🍕' },
  { id: 5, name: 'Orange Juice', category: 'Drinks', price: 2.5, emoji: '🍊' },
  { id: 6, name: 'Water', category: 'Drinks', price: 1, emoji: '💧' }
];
export default foods;
